import { useState, useEffect } from "react";
import jsPDF from "jspdf";

export default function App() {
  const [inicio, setInicio] = useState(true);
  const [historial, setHistorial] = useState([]);
  const [contador, setContador] = useState(1);

  const [form, setForm] = useState({
    numero: contador,
    localidad: "",
    productor: "",
    fecha: "",
    hectareas: "",
    loteTexto: "",
    loteCoord: "",
    firma: "",
    observaciones: "",

    // 🟢 NUEVAS SECCIONES
    trabajos: [],
    pulverizacion: [],

    productos: Array.from({ length: 5 }, () => ({ nombre: "", dosis: "" })),
  });

  useEffect(() => {
    const data = localStorage.getItem("historial");
    if (data) setHistorial(JSON.parse(data));
  }, []);

  const guardarHistorial = () => {
    const nuevo = [...historial, form];
    setHistorial(nuevo);
    localStorage.setItem("historial", JSON.stringify(nuevo));
    setContador(contador + 1);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleProductoChange = (index, field, value) => {
    const nuevos = [...form.productos];
    nuevos[index][field] = value;
    setForm({ ...form, productos: nuevos });
  };

  const toggleCheckbox = (section, value) => {
    const lista = form[section];
    if (lista.includes(value)) {
      setForm({ ...form, [section]: lista.filter((v) => v !== value) });
    } else {
      setForm({ ...form, [section]: [...lista, value] });
    }
  };

  const generarPDF = () => {
    const doc = new jsPDF();

    const logo =
      "https://i.postimg.cc/GhxRz1yn/Chat-GPT-Image-31-mar-2026-07-01-09-p-m.png";

    doc.addImage(logo, "PNG", 140, 10, 50, 25);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text("AGROSOL S.A.", 10, 15);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.text("Servicios Agropecuarios", 10, 22);
    doc.text("Zona Rural - Escalada, Santa Fe", 10, 28);
    doc.text("Tel: 03498 - 15475238 / 15680331", 10, 34);

    doc.text("CUIT: 30-70805254-6", 10, 40);
    doc.text("Ingresos Brutos: 171-009434-7", 10, 46);
    doc.text("Inicio de Actividad: 01/09/2002", 10, 52);
    doc.text("IVA Responsable Inscripto", 10, 58);
    doc.text("Email: agrosol@gcrespo.com.ar", 10, 64);

    doc.line(10, 70, 200, 70);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text("ORDEN DE TRABAJO - PULVERIZACIÓN", 10, 80);
    doc.text(`N° ${form.numero}`, 170, 80);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);

    doc.text(`Localidad: ${form.localidad}`, 10, 95);
    doc.text(`Productor: ${form.productor}`, 10, 105);
    doc.text(`Fecha: ${form.fecha}`, 140, 105);

    doc.text(`Hectáreas: ${form.hectareas}`, 10, 120);
    doc.text(`Lote: ${form.loteTexto}`, 140, 120);

    doc.text(`Coordenadas: ${form.loteCoord}`, 10, 130);

    // 🟢 NUEVAS SECCIONES EN PDF
    doc.text(`Trabajo: ${form.trabajos.join(", ")}`, 10, 140);
    doc.text(`Pulverización: ${form.pulverizacion.join(", ")}`, 10, 150);

    let y = 165;

    doc.setFont("helvetica", "bold");
    doc.text("Producto", 10, y);
    doc.text("Dosis", 150, y);
    doc.line(10, y + 2, 200, y + 2);

    y += 12;
    doc.setFont("helvetica", "normal");

    form.productos.forEach((p) => {
      if (p.nombre) {
        doc.text(p.nombre, 10, y);
        doc.text(p.dosis, 150, y);
        y += 10;
      }
    });

    y += 10;

    doc.text("Observaciones:", 10, y);
    doc.rect(10, y + 5, 180, 20);
    doc.text(form.observaciones || "", 12, y + 12);

    y += 35;
    doc.line(10, y, 100, y);
    doc.text("Firma", 10, y + 6);
    doc.text(form.firma || "", 10, y + 14);

    doc.save("remito_agrosol.pdf");

    guardarHistorial();
  };

  if (inicio) {
    return (
      <div style={inicioStyle}>
        <h1 style={{ color: "white", fontSize: 32 }}>REMITERO DIGITAL</h1>
        <p style={{ color: "white" }}>create by Fermin Moscardini</p>
        <button style={btnInicio} onClick={() => setInicio(false)}>
          Comenzar con el remito
        </button>
      </div>
    );
  }

  return (
    <div style={bg}>
      <div style={container}>
        <h2>Remito</h2>

        <input
          name="localidad"
          placeholder="Localidad"
          onChange={handleChange}
          style={input}
        />
        <input
          name="productor"
          placeholder="Productor"
          onChange={handleChange}
          style={input}
        />
        <input type="date" name="fecha" onChange={handleChange} style={input} />
        <input
          name="hectareas"
          placeholder="Hectáreas"
          onChange={handleChange}
          style={input}
        />
        <input
          name="loteTexto"
          placeholder="Lote"
          onChange={handleChange}
          style={input}
        />

        <div style={{ display: "flex", gap: 10 }}>
          <input
            name="loteCoord"
            placeholder="Coordenadas"
            onChange={handleChange}
            style={{ ...input, flex: 1 }}
          />
          <button onClick={() => window.open("https://www.google.com/maps")}>
            📍
          </button>
        </div>

        <h3>Tipo de Trabajo</h3>
        {["Barbecho", "Trigo", "Girasol", "Sorgo", "Maiz", "Soja", "Otros"].map(
          (t) => (
            <label key={t} style={{ display: "block" }}>
              <input
                type="checkbox"
                onChange={() => toggleCheckbox("trabajos", t)}
              />{" "}
              {t}
            </label>
          )
        )}

        <h3>Tipo de Pulverización</h3>
        {["Insecticida", "Herbicida", "Fungicida", "Fertilizante Líquido"].map(
          (p) => (
            <label key={p} style={{ display: "block" }}>
              <input
                type="checkbox"
                onChange={() => toggleCheckbox("pulverizacion", p)}
              />{" "}
              {p}
            </label>
          )
        )}

        <h3>Productos</h3>
        {form.productos.map((p, i) => (
          <div key={i} style={{ display: "flex", gap: 10 }}>
            <input
              placeholder={`Producto ${i + 1}`}
              value={p.nombre}
              onChange={(e) =>
                handleProductoChange(i, "nombre", e.target.value)
              }
              style={{ ...input, flex: 1 }}
            />
            <input
              placeholder="Dosis"
              value={p.dosis}
              onChange={(e) => handleProductoChange(i, "dosis", e.target.value)}
              style={{ ...input, width: 100 }}
            />
          </div>
        ))}

        <textarea
          name="observaciones"
          placeholder="Observaciones"
          onChange={handleChange}
          style={input}
        />
        <input
          name="firma"
          placeholder="Firma"
          onChange={handleChange}
          style={input}
        />

        <button onClick={generarPDF} style={btn}>
          Generar PDF
        </button>

        <button
          onClick={() => {
            const mensaje = `Remito N° ${form.numero} - ${form.productor}`;
            window.open(`https://wa.me/?text=${encodeURIComponent(mensaje)}`);
          }}
          style={btn}
        >
          Compartir por WhatsApp
        </button>

        <h3>Historial</h3>
        {historial.map((h, i) => (
          <div key={i} style={histItem}>
            <p>
              {h.productor} - {h.hectareas}ha - {h.loteTexto}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

const inicioStyle = {
  height: "100vh",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  alignItems: "center",
  background: "green",
};
const btnInicio = { padding: 15, background: "white" };
const bg = { padding: 20 };
const container = { maxWidth: 700, margin: "auto" };
const input = { width: "100%", padding: 10, marginTop: 10 };
const btn = { marginTop: 10, padding: 10, width: "100%" };
const histItem = { background: "#eee", padding: 10, marginTop: 5 };
